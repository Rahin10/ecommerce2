<?php

namespace App\Entity;

use App\Repository\ProductRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ProductRepository::class)
 */
class Product
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $naam;

    /**
     * @ORM\Column(type="string", length=2555)
     */
    private $omschrijving;

    /**
     * @ORM\Column(type="float")
     */
    private $prijs;

    /**
     * @ORM\Column(type="boolean")
     */
    private $frontpage;

    /**
     * @ORM\Column(type="integer")
     */
    private $btw;

    /**
     * @ORM\OneToMany(targetEntity=Image::class, mappedBy="product_id")
     */
    private $extra;

    public function __construct()
    {
        $this->extra = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNaam(): ?string
    {
        return $this->naam;
    }

    public function setNaam(string $naam): self
    {
        $this->naam = $naam;

        return $this;
    }

    public function getOmschrijving(): ?string
    {
        return $this->omschrijving;
    }

    public function setOmschrijving(string $omschrijving): self
    {
        $this->omschrijving = $omschrijving;

        return $this;
    }

    public function getPrijs(): ?float
    {
        return $this->prijs;
    }

    public function setPrijs(float $prijs): self
    {
        $this->prijs = $prijs;

        return $this;
    }

    public function getFrontpage(): ?bool
    {
        return $this->frontpage;
    }

    public function setFrontpage(bool $frontpage): self
    {
        $this->frontpage = $frontpage;

        return $this;
    }

    public function getBtw(): ?int
    {
        return $this->btw;
    }

    public function setBtw(int $btw): self
    {
        $this->btw = $btw;

        return $this;
    }

    /**
     * @return Collection|Image[]
     */
    public function getExtra(): Collection
    {
        return $this->extra;
    }

    public function addExtra(Image $extra): self
    {
        if (!$this->extra->contains($extra)) {
            $this->extra[] = $extra;
            $extra->setProductId($this);
        }

        return $this;
    }

    public function removeExtra(Image $extra): self
    {
        if ($this->extra->contains($extra)) {
            $this->extra->removeElement($extra);
            // set the owning side to null (unless already changed)
            if ($extra->getProductId() === $this) {
                $extra->setProductId(null);
            }
        }

        return $this;
    }
}
